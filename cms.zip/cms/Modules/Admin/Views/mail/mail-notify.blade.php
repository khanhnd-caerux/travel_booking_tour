<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Thông báo đặt tour - Ha Giang Travel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f8;
            margin: 0;
            padding: 0;
            color: #333;
        }

        .container {
            max-width: 600px;
            margin: 30px auto;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
            overflow: hidden;
        }

        .header {
            background-color: #1a73e8;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        .header h1 {
            margin: 0;
            font-size: 20px;
        }

        .content {
            padding: 20px;
        }

        .content p {
            margin: 10px 0;
            font-size: 15px;
        }

        .label {
            font-weight: bold;
            color: #444;
        }

        .value {
            color: #000;
        }

        .cta-button {
            display: inline-block;
            margin: 20px 0;
            padding: 12px 24px;
            background-color: #1a73e8;
            color: #fff !important;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }

        .footer {
            text-align: center;
            padding: 15px;
            font-size: 13px;
            background-color: #f0f0f0;
            color: #777;
        }

        a {
            color: #1a73e8;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">
            <h1>Thông báo: Có khách hàng đặt tour</h1>
        </div>

        <div class="content">
            <p><span class="label">Tên khách hàng:</span> <span class="value">{{ $data['customer'] }}</span></p>
            <p><span class="label">Số điện thoại:</span> <span class="value">{{ $data['phone'] }}</span></p>
            <p><span class="label">Email:</span> <span class="value">{{ $data['email'] }}</span></p>
            <p><span class="label">Ghi chú:</span> <span class="value">{{ $data['note'] }}</span></p>

            <p style="text-align:center;">
                <a href="{{ $data['link'] }}" class="cta-button" target="_blank">Xem Thông Tin Đặt Tour</a>
            </p>
        </div>

        <div class="footer">
            © 2025 Ha Giang Travel Mountain. Mọi thông tin đều được bảo mật.
        </div>
    </div>
</body>

</html>
