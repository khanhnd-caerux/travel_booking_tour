<div class="book_now" style="position: fixed; z-index: 100;">
    <img class="img_booknow" id="img_booknow" src="{{ asset('frontend/book_now.png') }}" alt="Book Now">
</div>
<div class="contact_layout d-none" id="contact_layout">
    <div class="contact_form d-none" id="contact_form">
        <button class="btn_close" id="close">X</button>
        <form action="{{ route('client.contact.store') }}" method="post">
            @csrf
            <h1>@lang('language.labelForm')</h1>
            <p>@lang('language.descForm')</p>
            <div class="column">
                <input type="text" name="honeypot" style="display:none;">
                <label for="the-name">@lang('language.nameCustomer')</label>
                <input type="text" name="name" id="the-name">
                <label for="the-email">@lang('language.emailCustomer')</label>
                <input type="email" name="email" id="the-email">
                <label for="the-phone">@lang('language.phoneCustomer')</label>
                <div class="flex_phone">
                    <select name="code_phone" id="the-phone" style="width: 50%;">
                        <option value="+84">(+84) Vietnam</option>
                        @if (config('country.countries'))
                            @foreach (config('country.countries') as $country)
                                <option value="{{ $country["code"] }}">
                                    {{ '(' . $country['code'] . ') ' . $country['country']  }}
                                </option>
                            @endforeach
                        @endif
                    </select>
                    <input type="tel" style="width: 50%;" name="phone_number" id="the-phone">
                </div>
                <label for="the-reason">@lang('language.pick')</label>
                <select name="url" id="the-reason">
                    <option value="1">@lang('language.choose')</option>
                    @if ($tours)
                        @foreach ($tours as $tour)
                            @if ($tour->category->locale == session()->get('locale'))
                                <option value="{{ config('app.url') . '/detail-content/' . $tour->slug }}">{{ $tour->name }}
                                </option>
                            @endif
                        @endforeach
                    @endif
                </select>
                <label for="the-message">@lang('language.note')</label>
                <textarea name="note" id="the-message"></textarea>
                <form action="?" method="post" id="captcha_form">
                    <div class="g-recaptcha" id="captcha" data-sitekey="6Ld0lZEUAAAAAJAK1wPWcVxwOlc1qgFcSIcU1das"
                        data-callback="onCallBack" data-expired-callback="onCallBack">
                    </div>
                </form>
                <input type="submit" value="@lang('language.send')">
            </div>
        </form>
    </div>
</div>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<style>
    .d-none {
        display: none;
    }

    .contact_form {
        position: fixed;
        width: 40%;
        left: 50%;
        background: #f0f0f0;
        padding: 10px;
        top: 50%;
        transform: translate(-50%, -50%);
        z-index: 9999;
        border-radius: 15px;
    }

    .contact_layout {
        position: fixed;
        background: #00000070;
        width: 100%;
        height: 100vh;
        z-index: 9000;
        top: 0;
        left: 0;
    }

    .flex_phone {
        display: flex;
        justify-content: space-between;
    }

    .contact_form h1,
    .contact_form p {
        text-align: center;
    }

    label {
        display: block;
        margin: 1em 0 .2em;
    }

    /* single-line text, checkbox, and button */
    input,
    select,
    textarea {
        display: block;
        width: 100%;
        padding: .3em;
        font-size: 20px;
        background-color: #fbfbfb;
        border: solid 1px #CCC;
        resize: vertical;
    }

    textarea {
        min-height: 60px;
    }

    select {
        color: indigo;
    }

    option {
        color: blue;
        background: lavenderBlush;
    }

    input[type=checkbox] {
        display: inline;
        width: auto;
        color: red;
    }

    input[type=submit] {
        background: lightcoral;
        margin: 1em 0 0;
        color: white;
        border: none;
        float: left;
        width: 100%;
        margin-right: 10px;
        border-radius: 8px;
        transition: all .3s ease-out;
    }

    input:focus,
    input:hover,
    select:focus,
    select:hover,
    textarea:focus,
    textarea:hover {
        background: lavenderBlush;
    }

    /* hover and focus states */
    input[type=submit]:hover,
    input[type=submit]:focus {
        background: lightgreen;
        outline: none;
    }

    @media screen and (min-width:600px) {

        /*  make the form 2 columns */
        form:after {
            content: '';
            display: block;
            clear: both;
        }

        .column {
            width: 100%;
            padding: 1em;
            float: left;
        }
    }

    .book_now {
        right: 20px;
        bottom: 100px;
    }

    .book_now .img_booknow {
        cursor: pointer;
        width: 180px;
        height: auto;
        border-radius: 15px;
        animation: bounce 2s ease infinite;
    }

    @keyframes bounce {

        0%,
        20%,
        50%,
        80%,
        100% {
            transform: translateY(0);
        }

        40% {
            transform: translateY(-20px);
        }

        60% {
            transform: translateY(-10px);
        }
    }

    .btn_close {
        padding: 10;
        border-radius: 10px;
        border: none;
        position: absolute;
        font-size: 20px;
        top: 5px;
        right: 5px;
    }

    @media only screen and (max-width: 600px) {
        .contact_form {
            width: 80%;
        }

        .hc-nav-trigger {
            z-index: 10;
        }
    }
</style>
<script>
    $("#img_booknow").click(function () {
        $("#contact_form").toggleClass('d-none');
        $("#contact_layout").toggleClass('d-none');
    });
    $("#close").click(function () {
        $("#contact_form").toggleClass('d-none');
        $("#contact_layout").toggleClass('d-none');
    });
</script>
